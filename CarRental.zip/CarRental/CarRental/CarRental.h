#pragma once
#include <vector>
#include <memory>

#include "Car.h"


class CarRental
{
public:
	CarRental();
	~CarRental();
	void AddCar(std::shared_ptr<Car>& newCar);
	int GetTotalNumberOfSeats();
private:
	std::vector<std::shared_ptr<Car>> m_vCars;
};

