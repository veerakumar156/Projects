#include "stdafx.h"
#include "CarRental.h"


CarRental::CarRental()
{

}


CarRental::~CarRental()
{
}

void CarRental::AddCar(std::shared_ptr<Car>& newCar)
{
	m_vCars.push_back(newCar);
}


int CarRental::GetTotalNumberOfSeats()
{
	int num = 0;
	for (auto car : m_vCars)
		num += car->GetNumberOfSeats();
	return num;
}
