#pragma once
#include <string>

class Car
{
public:
	Car();
	virtual ~Car();
	virtual int GetNumberOfSeats();
private:
	std::string m_sLicensePlate;
	std::string m_sBrand;
};

class Suv :public Car
{
public:
	int GetNumberOfSeats();
	Suv(const bool&);
private:
	bool m_bThirdRow;
};

class Sedan :public Car
{
public:
	int GetNumberOfSeats();
	Sedan(const bool&);
private:
	bool m_bSportsPackage;

};