#include "stdafx.h"
#include "Car.h"


Car::Car()
{
}


Car::~Car()
{
}

int Car::GetNumberOfSeats()
{
	return 4;
}


//standard design of SUVs with third row assumed to have 7 seats
int Suv::GetNumberOfSeats()
{
	if (m_bThirdRow)
		return 7;
	else
		return 4;

}

Suv::Suv(const bool& bThirdrow)
{
	m_bThirdRow = bThirdrow;
}

Sedan::Sedan(const bool& bSportsPack)
{
	m_bSportsPackage = bSportsPack;
}

//standard design of sedans assumed to have 4 seats
int Sedan::GetNumberOfSeats()
{
	return Car::GetNumberOfSeats();
}
